
<?php $__env->startSection('content'); ?>

    <!--header section start-->
    <section class="breadcrumb-section" style="background-image: url('<?php echo e(asset('assets/images/logo/bb.png')); ?>')">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- breadcrumb Section Start -->
                    <div class="breadcrumb-content">
                        <h5><?php echo e($page_title); ?></h5>
                    </div>
                    <!-- Breadcrumb section End -->
                </div>
            </div>
        </div>
    </section>

    <Section class="pricing2-section section-padding section-background">
        <div class="container">
            <!-- Pricing List Start -->
            <?php if($plans): ?>
                <?php $i = 0 ?>
                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $i++ ?>
                    <?php if($i%4 == 1): ?>
                        <br>
                        <div class="row">
                            <?php endif; ?>
                            <div class="col-md-3 col-sm-6">
                                <!-- Pricing  List1 Start -->
                                <div class="pricing-list1 pricing-list2">
                                    <div class="pricing-thumb">
                                        <i class="fa fa-server" aria-hidden="true"></i>
                                    </div>
                                    <div class="pricing-header1">
                                        <h5><?php echo e($package->title); ?></h5>
                                        <p><?php echo e($package->speed); ?></p>
                                        <p class="text-center" style="text-transform: uppercase;font-size: 12px;color: #fff;">Get <?php echo e($package->return); ?> <?php echo e($package->category->code); ?> Per Day For <?php echo e($package->period . ' ' . $package->ptyp); ?></p>
                                    </div>
                                    <div class="pricing-amount1"><p><?php echo e($basic->symbol); ?></p><span> <?php echo e($package->price); ?></span></div>
                                    <div class="pricing-info1">
                                        <ul>
                                            <?php if(@unserialize($package->features)): ?>
                                                <?php $__currentLoopData = @unserialize($package->features); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <p><?php echo e($feature); ?></p>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <a href="<?php echo e(route('plan.purchase', $package->id)); ?>">Buy Now</a>
                                </div>
                                <!-- Pricing List1 End -->
                            </div>


                            <?php if($i%4 == 0): ?>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <!-- Pricing List End -->
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.newfrontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>