
<?php $__env->startSection('content'); ?>

    <!--header section start-->
   <section class="breadcrumb-section" style="background-image: url('<?php echo e(asset('assets/images/logo/bb.png')); ?>')">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <!-- breadcrumb Section Start -->
            <div class="breadcrumb-content">
               <h5><?php echo e($page_title); ?></h5>
            </div>
            <!-- Breadcrumb section End -->
          </div>
        </div>
      </div>
    </section>
    <!--about us page content start-->
    <section class="section-padding about-us-page">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $menu1->description; ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.newfrontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>