<!doctype html>
<html>
    <head>
        <title><?php echo e($page_title); ?></title>
    </head>
    <body  oncontextmenu="return false">
        <?php if($fund->payment_type == 1): ?>
            <form action="https://secure.paypal.com/uk/cgi-bin/webscr" method="post" name="paypal" id="payform">
                <input type="hidden" name="cmd" value="_xclick" />
                <input type="hidden" name="business" value="<?php echo e($fund->payment->val1); ?>" />
                <input type="hidden" name="cbt" value="<?php echo e($basic->title); ?>" />
                <input type="hidden" name="currency_code" value="USD" />
                <input type="hidden" name="quantity" value="1" />
                <input type="hidden" name="item_name" value="Add Fund to <?php echo e($basic->title); ?>" />

                <!-- Custom value you want to send and process back in the IPN -->
                <input type="hidden" name="custom" value="<?php echo e($fund->custom); ?>" />

                <input name="amount" type="hidden" value="<?php echo e($fund->usd); ?>">
                <input type="hidden" name="return" value="<?php echo e(route('deposit-fund')); ?>"/>
                <input type="hidden" name="cancel_return" value="<?php echo e(route('deposit-fund')); ?>" />
                <!-- Where to send the PayPal IPN to. -->
                <input type="hidden" name="notify_url" value="<?php echo e(route('paypal-ipn')); ?>" />
            </form>
        <?php elseif($fund->payment_type == 2): ?>
            <form action="https://perfectmoney.is/api/step1.asp" method="POST" id="payform">
                <input type="hidden" name="PAYEE_ACCOUNT" value="<?php echo e($fund->payment->val1); ?>">
                <input type="hidden" name="PAYEE_NAME" value="<?php echo e($basic->title); ?>">
                <input type='hidden' name='PAYMENT_ID' value='<?php echo e($fund->custom); ?>'>
                <input type="hidden" name="PAYMENT_AMOUNT"  value="<?php echo e(round(($fund->usd),2)); ?>">
                <input type="hidden" name="PAYMENT_UNITS" value="USD">
                <input type="hidden" name="STATUS_URL" value="<?php echo e(route('perfect-ipn')); ?>">
                <input type="hidden" name="PAYMENT_URL" value="<?php echo e(route('deposit-fund')); ?>">
                <input type="hidden" name="PAYMENT_URL_METHOD" value="GET">
                <input type="hidden" name="NOPAYMENT_URL" value="<?php echo e(route('deposit-fund')); ?>">
                <input type="hidden" name="NOPAYMENT_URL_METHOD" value="GET">
                <input type="hidden" name="SUGGESTED_MEMO" value="<?php echo e($basic->title); ?>">
                <input type="hidden" name="BAGGAGE_FIELDS" value="IDENT"><br>
            </form>
        <?php elseif($fund->payment_type == 3): ?>
            <form action="<?php echo e(route('btc-preview')); ?>" method="POST" id="payform">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="amount" value="<?php echo e(round(($fund->usd),3)); ?>">
                <input type="hidden" name="fund_id" value="<?php echo e($fund->id); ?>">
                <input type="hidden" name="custom" value="<?php echo e($fund->custom); ?>">
            </form>
        <?php elseif($fund->payment_type == 4): ?>
            <form action="<?php echo e(route('stripe-preview')); ?>" method="POST" id="payform">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="amount" value="<?php echo e(round(($fund->usd),2)); ?>">
                <input type="hidden" name="fund_id" value="<?php echo e($fund->id); ?>">
                <input type="hidden" name="custom" value="<?php echo e($fund->custom); ?>">
                <input type="hidden" name="url" value="<?php echo e(route('deposit-fund')); ?>">
            </form>
        <?php elseif($fund->payment_type == 5): ?>
            <form action="<?php echo e(route('coin.pay.preview')); ?>" method="POST" id="payform">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="amount" value="<?php echo e(round(($fund->usd),2)); ?>">
                <input type="hidden" name="fund_id" value="<?php echo e($fund->id); ?>">
            </form>
        <?php elseif($fund->payment_type == 6): ?>
            <form action="https://www.moneybookers.com/app/payment.pl" method="post" id="payform">
                <input name="pay_to_email" value="<?php echo e($fund->payment->val1); ?>" type="hidden">
                <input name="transaction_id" value="<?php echo e($fund->custom); ?>" type="hidden">
                <input name="return_url" value="<?php echo e(route('deposit-fund')); ?>" type="hidden">
                <input name="return_url_text" value="Return <?php echo e($basic->title); ?>" type="hidden">
                <input name="cancel_url" value="<?php echo e(route('deposit-fund')); ?>" type="hidden">
                <input name="status_url" value="<?php echo e(route('skrill-ipn')); ?>" type="hidden">
                <input name="language" value="EN" type="hidden">
                <input name="amount" value="<?php echo e($fund->usd); ?>" type="hidden">
                <input name="currency" value="USD" type="hidden">
                <input name="detail1_description" value="<?php echo e($basic->title); ?>" type="hidden">
                <input name="detail1_text" value="Add Fund To <?php echo e($basic->title); ?>" type="hidden">
                <input name="logo_url" value="<?php echo e(asset('assets/images/logo/logo.png')); ?>" type="hidden">
            </form>
        <?php endif; ?>

        <script type="text/javascript">
            function disableRightClick() {
                if (event.button == 2) {
                    alert('For Security Reason Right Click is Disabled')
                }
            }
            document.onmousedown = disableRightClick;
            document.getElementById("payform").submit();
        </script>
    </body>
</html>