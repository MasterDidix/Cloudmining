

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="content_padding">
    <div class="container user-dashboard-body">  
	<div class="row">
	<div class="col-md-12">
	<div class="panel panel-default">
		<div class="panel-heading">
			<h3 class="panel-title">Confirm Deposit</h3>
		</div>
		<div class="panel-body">

			<div  class="col-md-8 col-md-offset-2 text-center">

				<h1><i class="fa fa-usd"></i> <span class="text-info"><?php echo e($amon); ?></span> <i class="fa fa-exchange"></i> <i class="fa fa-bitcoin"></i> <span class="text-info"><?php echo e($bcoin); ?></span></h1>

			
			<b style="color: red; margin-top: 15px;"> Minimum 3 Confirmation Required to Credited Your Account.<br/>(It May Take Upto 2 to 24 Hours)</b>
			<br/>
			<p style="margin-top: 15px;"><?php echo $form; ?></p>
			</div>
			

		</div>
	</div>
	</div>
	</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>