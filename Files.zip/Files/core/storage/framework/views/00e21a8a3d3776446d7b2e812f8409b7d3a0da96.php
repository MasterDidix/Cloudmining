
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content_padding">
    <div class="container user-dashboard-body">

        <div class="row">
            <div class="col-md-12">

                <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                    <?php if($logs && count($logs)): ?>

                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php

                                switch ($log->status) {
                                    case 'requested':
                                        $panel = 'primary';
                                        $user = \App\User::find($log->sender);
                                        $sender = isset($user)?$user->name:'';
                                        $receiver = $log->receiver;
                                        break;
                                    case 'approved':
                                        $panel = 'primary';
                                        $user = \App\User::find($log->sender);
                                        $sender = isset($user)?$user->name:'';
                                        $receiver = $log->receiver;
                                        break;
                                    case 'refunded':
                                        $panel = 'danger';
                                        $user = \App\User::find($log->receiver);
                                        $receiver = isset($user)?$user->name:'';
                                        $sender = $log->sender;
                                        break;
                                    default:
                                        $panel = 'default';
                                        $receiver = $log->receiver;
                                        $sender = $log->sender;
                                    break;
                                }

                                switch ($log->type) {
                                    case 'PlanLog':
                                        $currency = $basic->currency;
                                        $sender_text = 'Purchased By';
                                        $byy = Auth::user()->name;
                                        if ($log->status == 'refunded') {
                                            $sender_text = 'Refunded To';
                                            $byy = Auth::user()->name;
                                        }
                                        break;
                                    case 'PaymentLog':
                                        $currency = $basic->currency;
                                        $sender_text = 'Paid By';
                                        $payment = \App\PaymentLog::findOrFail($log->track);
                                        $byy = $payment->payment->name . ' Deposit';
                                        break;
                                    case 'UserData':
                                        $data = \App\UserData::find($log->track);
                                        $currency = isset($data)?$data->miner->code:'';
                                        break;
                                    case 'WithdrawLog':
                                        if ($log->status == 'requested') {
                                            $panel = 'warning';
                                        }
                                        $withdraw = \App\WithdrawLog::find($log->track);
                                        $data = \App\UserData::find($withdraw->method_id);
                                        $currency = isset($data)?$data->miner->code:'';
                                        $sender_text = 'Withdraw To';
                                        $byy = $basic->title.' System';
                                        if ($log->status == 'refunded') {
                                            $sender_text = 'Refunded To';
                                            $byy = Auth::user()->name;
                                        }
                                        break;
                                    case 'ReturnLog':
                                        /*if ($log->status == 'requested') {
                                            $panel = 'warning';
                                        }*/

                                        $return = \App\ReturnLog::findOrFail($log->track);

                                        $plan_log = \App\PlanLog::findOrFail($return->plan_log);

                                        $currency = @$plan_log->plan->category->code;
                                        $sender_text = 'Return Generated By';
                                        $byy = @$plan_log->plan->title . ' PLAN';
                                        break;
                                    default:
                                        $currency = $basic->currency;
                                    break;
                                }

                            ?>

                            <div class="panel panel-<?php echo e($panel); ?>">
                                <div class="panel-heading" role="tab" id="heading-<?php echo e($log->id); ?>">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-<?php echo e($log->id); ?>" aria-expanded="false" aria-controls="collapse-<?php echo e($log->id); ?>">
                                            <div class="row">
                                                <div class="col-md-3" style="font-size: 20px;margin-top: 15px;">
                                                    <?php echo e($log->created_at->format('d M')); ?>

                                                </div>
                                                <div class="col-md-6 text-center">
                                                    <h4><?php echo e($log->description); ?></h4><span><?php echo e($sender_text); ?> <?php echo e($byy); ?></span>
                                                </div>
                                                <div class="col-md-3 text-right" style="font-size: 20px;margin-top: 15px;">
                                                    <?php echo e($log->gross_amount); ?> <?php echo e($currency); ?>

                                                </div>
                                            </div>
                                        </a>
                                    </h4>
                                </div>
                                <div id="collapse-<?php echo e($log->id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading-<?php echo e($log->id); ?>">
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <h3><?php echo e($sender_text); ?></h3>
                                                <div>
                                                    <strong style="font-size: 16px;"><?php echo e($byy); ?></strong>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <strong style="font-size: 20px;">Transaction ID</strong><br><br>
                                                <strong><?php echo e($log->trxid); ?></strong><br><br>
                                                <div>
                                                    <i class="fa fa-calendar"></i>  <?php echo e($log->created_at->format('d M, Y')); ?>

                                                    <i class="fa fa-clock-o"></i> <?php echo e($log->created_at->format('h:m a')); ?>

                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <strong style="font-size: 20px;">Details</strong><br><br>
                                                <div style="margin-left: 10px;">
                                                    Gross Amount: <?php echo e($log->gross_amount); ?> <?php echo e($currency); ?><br>
                                                    Charge: <?php echo e($log->charge); ?> <?php echo e($currency); ?><br>
                                                    Net Amount: <?php echo e($log->net_amount); ?> <?php echo e($currency); ?><br>
                                                </div>
                                            </div>
                                            <?php if(isset($log->custom) && !empty($log->custom)): ?>
                                                <br>
                                                <div class="col-md-12">
                                                    <strong style="font-size: 20px;">Message: </strong> <?php echo e($log->custom); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col-md-12 text-right">
                                    <?php echo e($logs->links()); ?>

                                </div>
                            </div>
                    <?php else: ?>
                        <h1 class="text-center text-danger">You Haven't Any Transaction Log. </h1>
                    <?php endif; ?>

                </div>

            </div>
        </div>
    
    </div>
</div>        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>