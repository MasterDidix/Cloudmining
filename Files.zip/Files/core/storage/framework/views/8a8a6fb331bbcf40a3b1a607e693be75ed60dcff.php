

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-12">

            <div class="portlet box blue">
                <div class="portlet-title">
                    <div class="caption uppercase">
                        <strong><i class="fa fa-info-circle"></i> <?php echo e($page_title); ?></strong>
                    </div>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"> </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <table class="table table-striped table-hover table-bordered" id="sample_editable_1">
                        <thead>
                        <tr>
                            <th> ID </th>
                            <th> Title </th>
                            <th> Price </th>
                            <th> Speed </th>
                            <th> Miner </th>
                            <th> Edit </th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php if($plans): ?>

                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td> <?php echo e($plan->id); ?> </td>
                                    <td> <?php echo e($plan->title); ?> </td>
                                    <td> <?php echo e($plan->price); ?> </td>
                                    <td> <?php echo e($plan->speed); ?> </td>
                                    <td> <?php echo e(isset($plan->category)?$plan->category->name:''); ?> </td>
                                    <td>
                                        <a href="<?php echo e(route('plan.edit', $plan->id)); ?>" class="btn btn-warning" role="button">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END EXAMPLE TABLE PORTLET-->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>