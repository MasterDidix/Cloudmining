

<?php $__env->startSection('content'); ?>
    
<?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content_padding">
    <div class="container user-dashboard-body">

        <div class="row">

            <?php if($coins && count($coins)): ?>

                <?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-sm-4 text-center">
                            <div class="panel panel-green panel-pricing">
                                <div class="panel-heading">
                                    <h3 style="font-size: 28px; color: #ffffff"><b><?php echo e($coin->miner->code); ?> Withdraw</b></h3>
                                </div>
                                <ul style='font-size: 15px;' class="list-group text-center bold">
                                    <li class="list-group-item">Wallet - <b><?php echo $coin->wallet; ?></b> </li>
                                    <li class="list-group-item">Current Balance - <b><?php echo $coin->balance; ?></b> <?php echo e($coin->miner->code); ?> </li>
                                    <li class="list-group-item">Charge - <?php echo e($basic->withdraw_charge); ?>% </li>
                                </ul>
                                <div class="panel-footer" style="overflow: hidden">
                                    <div class="col-sm-12">
                                        <a href="#" <?php if($basic->withdraw_status == 0): ?> disabled <?php endif; ?> class="btn btn-primary btn-block bold btn-own withc" data-code="<?php echo e($coin->miner->code); ?>" data-id="<?php echo e($coin->id); ?>"> Withdraw Now</a>
                                    </div>

                                </div>
                            </div>
                        </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h1 class="text-danger text-center">You Have No Coin Balance For Withdraw</h1>
            <?php endif; ?>

        </div>


        <div class="modal fade" id="withd">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title"><strong>Withdraw via <span id="edit_name"></span></strong> </h4>
                    </div>
                    <form method="post" action="<?php echo e(route('withdraw', 'general')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="method_id" id="edit_id" value="">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <span style="margin-bottom: 10px;"><code>Withdraw Charge : (<span id="edit_fix"></span> <?php echo e($basic->currency); ?> + <span id="edit_percent"></span>%)</code></span>
                                            <div class="input-group" style="margin-top: 10px;margin-bottom: 10px;">
                                                <input type="text" value="" id="amount" name="amount" class="form-control" required placeholder="Amount" />
                                                <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <br>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button type="submit" class="btn btn-primary btn-block btn-own">Withdraw Now</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


        <div class="modal fade" id="withc">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title"><strong><span id="edit_cname"></span> Withdraw</strong> </h4>
                    </div>
                    <form method="post" action="<?php echo e(route('withdraw', 'coin')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="miner_id" id="edit_cid" value="">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <span style="margin-bottom: 10px;"><code>Withdraw Charge : <?php echo e($basic->withdraw_charge); ?>%</code></span>
                                            <div class="input-group" style="margin-top: 10px;margin-bottom: 10px;">
                                                <input type="text" value="" id="amount" name="amount" class="form-control" required placeholder="Amount" />
                                                <span class="input-group-addon">&nbsp;<strong><span id="ccurrency"></span></strong></span>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                    <br>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button type="submit" class="btn btn-primary btn-block btn-own">Withdraw Now</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <?php if(session('message')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("<?php echo e(session('title')); ?>", "<?php echo e(session('message')); ?>", "<?php echo e(session('type')); ?>");

            });

        </script>

    <?php endif; ?>

    <?php if(session('alert')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "<?php echo session('alert'); ?>", "error");

            });

        </script>

    <?php endif; ?>

    <script>
        (function ($) {
            $(document).ready(function(){

                $('.withb').click(function (e) {

                    e.preventDefault();

                    var id = $(this).data('id');
                    var name = $(this).data('name');
                    var fix = $(this).data('fix');
                    var percent = $(this).data('percent');

                    $('#edit_id').val(id);
                    $('#edit_name').text(name);
                    $('#edit_fix').text(fix);
                    $('#edit_percent').text(percent);

                    $('#withd').modal();
                });

                $('.withc').click(function (e) {
                    e.preventDefault();
                    var code = $(this).data('code');
                    var id = $(this).data('id');

                    $('#edit_cname').text(code);
                    $('#edit_cid').val(id);
                    $('#ccurrency').text(code);

                    $('#withc').modal();
                });

            });
        })(jQuery);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>