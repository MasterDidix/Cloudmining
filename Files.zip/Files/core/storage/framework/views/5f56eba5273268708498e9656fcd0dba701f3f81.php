<?php $__env->startSection('style'); ?>
    <style>
        .input-text-box input{
            border: 1px solid #CCCCCC;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="content_padding">
    <div class="container user-dashboard-body">

        <?php if($fund): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default panel-shadow" data-collapsed="0">
                        <div class="panel-heading">
                            <div class="panel-title"><i class="fa fa-desktop"></i><strong> <?php echo e($page_title); ?></strong></div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label style="margin-top: 5px;font-size: 14px;" class="col-md-6 text-right control-label"><strong>Deposit Amount : </strong></label>

                                        <div class="col-md-6">
                                            <div class="input-group input-text-box">
                                                <input type="text" value="<?php echo e($fund->amount); ?>" readonly name="amount" id="amount" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                <span class="input-group-addon red">&nbsp;<strong><?php echo e($basic->currency); ?> </strong></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label style="margin-top: 5px;font-size: 14px;" class="col-md-6 text-right control-label"><strong>Charge : </strong></label>

                                        <div class="col-md-6">
                                            <div class="input-group input-text-box">
                                                <input type="text" value="<?php echo e($fund->charge); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label style="margin-top: 5px;font-size: 14px;" class="col-md-6 text-right control-label"><strong>Total Send : </strong></label>

                                        <div class="col-md-6">
                                            <div class="input-group input-text-box">
                                                <input type="text" value="<?php echo e($fund->amount + $fund->charge); ?>" readonly name="" id="" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label style="margin-top: 5px;font-size: 14px;" class="col-md-6 text-right control-label"><strong>Conversion Rate : </strong></label>

                                        <div class="col-md-6">
                                            <div class="input-group input-text-box">
                                                <input type="text" value="1 USD = <?php echo e($fund->payment->rate); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label style="margin-top: 5px;font-size: 14px;" class="col-md-6 text-right control-label"><strong>Total Amount : </strong></label>

                                        <div class="col-md-6">
                                            <div class="input-group input-text-box">
                                                <input type="text" value="<?php echo e(round($fund->net_amount, $basic->deci)); ?>" readonly name="charge" id="charge" class="form-control bold" placeholder="Enter Deposit Amount" required>
                                                <span class="input-group-addon red">&nbsp;<strong> <?php echo e($basic->currency); ?> </strong></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <hr>
                            <div class="row">
                                <div class="col-sm-6">
                                    <a href="<?php echo e(route('deposit-fund')); ?>" class="btn btn-primary btn-block btn-icon icon-left btn-own">
                                        Back to Payment Method Page
                                    </a>
                                </div>
                                <div class="col-sm-6">
                                    <a class="btn btn-success btn-block bold btn-icon icon-left btn-own" href="<?php echo e(route('deposit', $fund->custom)); ?>">
                                        Add Fund Now
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php if(session('message')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("<?php echo e((session('title') != NULL)?session('title'):'Success!'); ?>", "<?php echo e(session('message')); ?>", "<?php echo e((session('type') != NULL)?session('type'):'success'); ?>");

            });

        </script>

    <?php endif; ?>



    <?php if(session('alert')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");

            });

        </script>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>