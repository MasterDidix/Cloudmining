

<?php $__env->startSection('style'); ?>
    <style>
        input[type="text"] {
            width: 100%;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content_padding">
        <div class="container user-dashboard-body">

            <div class="row">
                <div class="login-admin login-admin1">
                    <div class="login-header text-center">
                        <h6><?php echo $page_title; ?></h6>
                    </div>
                    <?php echo Form::open(['method'=>'post','role'=>'form','class'=>'form-horizontal','files'=>true]); ?>

                    <div class="row">
                        <div class="col-md-9 col-md-offset-3">
                            <div class="row">

                                <?php if($user_datas): ?>

                                    <?php $__currentLoopData = $user_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="col-md-12"><strong style="text-transform: uppercase;"><?php echo e($user_data->miner->code); ?> Wallet :</strong></label>
                                                <div class="col-md-12">
                                                    <input type="text" name="<?php echo e($user_data->category_id); ?>" id="" value="<?php echo e($user_data->wallet); ?>" placeholder="<?php echo e($user_data->miner->name); ?> Wallet">
                                                </div>
                                            </div>
                                        </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group">
                            <div class="col-md-9 col-md-offset-3">
                                <button type="submit" class="new-btn-submit">UPDATE WALLET</button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>

    <?php if(session('message')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Success!", "<?php echo e(session('message')); ?>", "success");

            });

        </script>

    <?php endif; ?>

    <?php if(session('alert')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "<?php echo session('alert'); ?>", "error");

            });

        </script>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>