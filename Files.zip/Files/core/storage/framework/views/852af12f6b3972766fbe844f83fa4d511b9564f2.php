
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content_padding">
        <div class="container user-dashboard-body">
            <div class="row">
                <div class="col-md-12">

                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="admin-header-text">
                                <h3> Purchased Plan</h3>
                            </div>

                        </div>
                        <div class="panel-body">
                            <table class="table table-striped table-bordered table-hover" id="sample_1">

                                <thead>
                                <tr>
                                    <th>ID#</th>
                                    <th>Purchase Date</th>
                                    <th>Title</th>
                                    <th>Price</th>
                                    <th>Speed</th>
                                    <th>Return Per Day</th>
                                    <th>Miner</th>
                                    <th>Status</th>
                                </tr>
                                </thead>

                                <tbody>
                                <?php $i=0;?>
                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $i++;?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($log->created_at->format('d M, Y')); ?></td>
                                        <td><?php echo e($log->plan->title); ?></td>
                                        <td><?php echo e($log->plan->price); ?> <?php echo e($basic->currency); ?></td>
                                        <td><?php echo e($log->plan->speed); ?></td>
                                        <td><?php echo e($log->plan->return); ?> <?php echo e($log->plan->category->code); ?></td>
                                        <td><?php echo e($log->plan->category->name); ?></td>
                                        <td>
                                            <?php if($log->status == 0): ?>
                                                <button class="btn btn-warning">Pending</button>
                                            <?php elseif($log->status == 2): ?>
                                                <button class="btn btn-danger">Refunded</button>
                                            <?php elseif($log->status == 1): ?>
                                                <button class="btn btn-success">Activate</button>
                                            <?php elseif($log->status == -10): ?>
                                                <button class="btn btn-danger">Expaired</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>