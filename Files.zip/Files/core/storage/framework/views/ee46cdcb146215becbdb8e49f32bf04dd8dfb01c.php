
<?php $__env->startSection('content'); ?>

    <!--header section start-->
    <section class="breadcrumb-section" style="background-image: url('<?php echo e(asset('assets/images/logo/bb.png')); ?>')">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- breadcrumb Section Start -->
                    <div class="breadcrumb-content">
                        <h5><?php echo e($page_title); ?></h5>
                    </div>
                    <!-- Breadcrumb section End -->
                </div>
            </div>
        </div>
    </section>

    <?php if($steps): ?>
        <section class="section-padding about-us-page">
            <div class="container">
                <div class="row">
                <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6" style="text-align: center;">
                        <h4><?php echo e($step->name); ?></h4>
                        <img src="<?php echo e(asset('assets/images/' . $step->image)); ?>" alt="<?php echo e($step->name); ?>" style="width: 150px;height: 150px;border-radius: 76px;">
                        <p style="font-size: 14px;margin-top: 20px;">
                            <?php echo e($step->description); ?>

                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-md-4 col-md-offset-4" style="text-align: center;margin-top: 20px;">
                        <a href="<?php echo e(url('user/packages')); ?>" class="btn btn-success">Start Now</a>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.newfrontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>