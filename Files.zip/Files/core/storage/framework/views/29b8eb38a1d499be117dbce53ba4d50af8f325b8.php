<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.breadcam', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="content_padding">
    <div class="container user-dashboard-body">
        <?php if($methods): ?>
            <div class="row">
            <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="panel panel-default" data-collapsed="0">
                        <!-- panel head -->
                        <div class="panel-heading">
                            <div class="panel-title"><strong><?php echo e($method->name); ?></strong></div>

                        </div>
                        <!-- panel body -->
                        <div class="panel-body">
                            <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($method->image); ?>" alt="<?php echo e($method->name); ?>">
                        </div>
                        <div class="panel-footer">
                            <a href="#" class="btn btn-primary btn-block btn-icon icon-lef bold uppercaset toggle btn-own" data-name="<?php echo e($method->name); ?>" data-type="<?php echo e($method->id); ?>" data-fix="<?php echo e($method->fix); ?>" data-per="<?php echo e($method->percent); ?>">ADD FUND</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="modal fade" id="modd">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title bold uppercase">Add Fund via <span id="m-name"></span></h4>
            </div>
            <?php echo e(Form::open()); ?>

            <input type="hidden" name="payment_type" id="m-type" value="">
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-12">
                        <span style="margin-bottom: 10px;"><code>Deposit Charge : (<span id="m-fix"></span> <?php echo e($basic->currency); ?> + <span id="m-per"></span> %)</code></span>
                        <div class="input-group" style="margin-top: 10px;margin-bottom: 10px;">
                                <input type="text" value="" id="amount" name="amount" class="form-control" required placeholder="Amount"/>
                                <span class="input-group-addon">&nbsp;<strong><?php echo e($basic->currency); ?></strong></span>
                        </div>
                    </div>
                    <br>
                    <br>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <button class="btn btn-primary btn-block bold uppercase btn-own">Add Fund</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <?php if(session('message')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("<?php echo e(session('title')); ?>", "<?php echo e(session('message')); ?>", "<?php echo e(session('type')); ?>");

            });

        </script>

    <?php endif; ?>



    <?php if(session('alert')): ?>

        <script type="text/javascript">

            $(document).ready(function(){

                swal("Sorry!", "<?php echo e(session('alert')); ?>", "error");

            });

        </script>

    <?php endif; ?>

    <script>
        (function ($) {
            $(document).ready(function () {
                $('.toggle').click(function (e) {
                    e.preventDefault();
                    var name = $(this).data('name');
                    var type = $(this).data('type');
                    var fix = $(this).data('fix');
                    var per = $(this).data('per');

                    $('#m-name').text(name);
                    $('#m-type').val(type);
                    $('#m-fix').text(fix);
                    $('#m-per').text(per);

                    $('#modd').modal();
                });
            });
        })(jQuery);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-frontend.user-dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>